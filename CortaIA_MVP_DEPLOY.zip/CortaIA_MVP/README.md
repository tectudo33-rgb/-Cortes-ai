# CortaIA MVP

Aplicação web responsiva para enviar vídeos, transcrever fala, selecionar até 10 trechos, gerar clipes verticais 1080x1920 com legendas e baixar MP4 individualmente ou em ZIP.

## Publicar pelo celular com GitHub + Render
1. Extraia o ZIP no celular.
2. No GitHub, crie um repositório novo chamado `cortaia`.
3. No repositório, use **Add file → Upload files** e envie `app.py`, `index.html`, `requirements.txt`, `Dockerfile`, `render.yaml`, `README.md` e `.gitignore` (não envie a pasta `data` nem `.venv`). Faça **Commit changes**.
4. Entre no Render, conecte sua conta GitHub e escolha **New → Blueprint** para usar `render.yaml`, ou **New → Web Service** e selecione o repositório `cortaia`.
5. Se criar Web Service manualmente, escolha **Docker** como runtime e mantenha o Dockerfile na raiz. Inicie o deploy.
6. Quando o deploy terminar, abra o endereço `*.onrender.com` fornecido pelo Render e teste com um vídeo curto.

## Rodar localmente
Requer Python 3.10+, FFmpeg e ffprobe. Instale dependências com `pip install -r requirements.txt` e execute `uvicorn app:app --host 0.0.0.0 --port 8000`.

## Limitações do MVP
- A seleção de momentos usa transcrição e heurísticas simples; não é uma compreensão semântica avançada.
- O enquadramento vertical é um recorte central, sem rastreamento de rosto.
- O primeiro uso do faster-whisper baixa o modelo e pode demorar. O plano gratuito pode não ter memória/CPU suficiente para vídeos longos; processamento pesado pode exigir plano pago.
- O sistema de arquivos padrão do Render é efêmero: arquivos enviados e resultados podem desaparecer em reinicializações/deploys. Para uso real, configure armazenamento persistente/objeto, limites de upload, limpeza automática e uma fila de tarefas. O plano gratuito do Render não oferece disco persistente.
- Use apenas vídeos que você possui ou tem autorização para editar.
