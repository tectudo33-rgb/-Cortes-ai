import os, uuid, shutil, zipfile, subprocess, re, json
from pathlib import Path
from typing import Any
from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

ROOT=Path(__file__).resolve().parent
DATA=ROOT/"data"; UP=DATA/"uploads"; JOBS=DATA/"jobs"; OUT=DATA/"outputs"
for p in (UP,JOBS,OUT): p.mkdir(parents=True,exist_ok=True)
app=FastAPI(title="CortaIA")
app.mount("/outputs",StaticFiles(directory=str(OUT)),name="outputs")
model=None

def ffmpeg_check():
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        raise RuntimeError("Instale FFmpeg e ffprobe e adicione-os ao PATH.")

def duration(path):
    x=subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",str(path)],capture_output=True,text=True,check=True)
    return max(.1,float(x.stdout.strip()))

def transcribe(path):
    global model
    from faster_whisper import WhisperModel
    if model is None:
        model=WhisperModel(os.getenv("CORTAIA_MODEL","base"),device=os.getenv("CORTAIA_DEVICE","cpu"),compute_type=os.getenv("CORTAIA_COMPUTE","int8"))
    segs,_=model.transcribe(str(path),vad_filter=True)
    return [{"start":float(s.start),"end":float(s.end),"text":s.text.strip()} for s in segs if s.text.strip()]

WORDS=["segredo","nunca","sempre","erro","melhor","verdade","atenção","descobri","resultado","dinheiro","como","absurdo","importante","dica","ninguém","finalmente","surpresa"]
def score(t):
    x=t.lower(); n=min(len(t)/35,2)
    n+=2 if "?" in t else 0
    n+=1 if "!" in t else 0
    n+=.7 if re.search(r"\d",t) else 0
    n+=sum(.8 for w in WORDS if w in x)
    return n-.7 if len(t.split())<4 else n

def pick(segs,dur,count=10):
    if not segs:
        length=min(30,max(8,dur/count)); return [{"start":max(0,min(dur-length,i*max(0,dur-length)/max(1,count-1))),"end":min(dur,max(0,min(dur-length,i*max(0,dur-length)/max(1,count-1)))+length),"title":f"Momento {i+1}"} for i in range(count)]
    c=[]
    for i,s in enumerate(segs):
        j=i
        while j+1<len(segs) and segs[j+1]["end"]-s["start"]<32: j+=1
        text=" ".join(z["text"] for z in segs[i:j+1])
        start=max(0,s["start"]-3); end=min(dur,max(segs[j]["end"]+3,start+12))
        c.append({"start":start,"end":max(start+1,end),"title":text[:90],"score":sum(score(z["text"]) for z in segs[i:j+1])})
    c.sort(key=lambda x:x["score"],reverse=True); chosen=[]
    for z in c:
        if all(z["end"]<=a["start"] or z["start"]>=a["end"] for a in chosen): chosen.append(z)
        if len(chosen)==count: break
    if len(chosen)<count:
        for z in sorted(c,key=lambda x:x["start"]):
            if z not in chosen: chosen.append(z)
            if len(chosen)==count: break
    return sorted(chosen[:count],key=lambda x:x["start"])

def ass_time(t):
    c=round(t*100); h,c=divmod(c,360000); m,c=divmod(c,6000); s,c=divmod(c,100); return f"{h}:{m:02d}:{s:02d}.{c:02d}"
def ass_escape(s): return s.replace("\\",r"\\").replace("{",r"\{").replace("}",r"\}").replace("\n"," ")

def make_ass(segs,start,end,path):
    header="""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,58,&H00FFFFFF,&H0000FFFF,&H00111111,&H80000000,-1,0,0,0,100,100,0,0,1,5,2,2,70,70,250,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    ev=[]
    for s in segs:
        if s["end"]<=start or s["start"]>=end: continue
        text=ass_escape(s["text"])
        ev.append(f"Dialogue: 0,{ass_time(max(0,s['start']-start))},{ass_time(min(end-start,s['end']-start))},Default,,0,0,0,,{text}")
    Path(path).write_text(header+"\n".join(ev)+"\n",encoding="utf-8")

def run(cmd):
    p=subprocess.run(cmd,capture_output=True,text=True)
    if p.returncode: raise RuntimeError((p.stderr or "Erro FFmpeg")[-1500:])

def process(jid,src):
    jf=JOBS/f"{jid}.json"; d={"id":jid,"status":"processing","progress":5,"message":"Preparando vídeo","clips":[]}; jf.write_text(json.dumps(d,ensure_ascii=False))
    try:
        ffmpeg_check(); dur=duration(src)
        d.update(progress=12,message="Transcrevendo áudio"); jf.write_text(json.dumps(d,ensure_ascii=False))
        segs=transcribe(src); clips=pick(segs,dur)
        folder=OUT/jid; folder.mkdir(parents=True,exist_ok=True); results=[]
        for i,c in enumerate(clips,1):
            ass=folder/f"sub_{i:02}.ass"; make_ass(segs,c["start"],c["end"],ass)
            assarg=str(ass.resolve()).replace("\\","/").replace(":","\\:")
            vf=f"scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,subtitles='{assarg}'"
            out=folder/f"corte_{i:02}.mp4"
            run(["ffmpeg","-y","-ss",str(c["start"]),"-i",str(src),"-t",str(c["end"]-c["start"]),"-vf",vf,"-c:v","libx264","-preset","veryfast","-crf","19","-c:a","aac","-b:a","192k","-movflags","+faststart",str(out)])
            results.append({"index":i,"title":c["title"] or f"Corte {i}","start":c["start"],"end":c["end"],"duration":round(c["end"]-c["start"],1),"url":f"/outputs/{jid}/{out.name}"})
            d.update(progress=35+int(60*i/max(1,len(clips))),message=f"Renderizando corte {i}/{len(clips)}",clips=results); jf.write_text(json.dumps(d,ensure_ascii=False))
        zp=folder/"todos_os_cortes.zip"
        with zipfile.ZipFile(zp,"w",zipfile.ZIP_DEFLATED) as z:
            for f in folder.glob("corte_*.mp4"): z.write(f,f.name)
        d.update(status="completed",progress=100,message="Concluído",clips=results,zip_url=f"/outputs/{jid}/todos_os_cortes.zip")
    except Exception as e: d.update(status="error",progress=100,message=str(e),error=str(e))
    jf.write_text(json.dumps(d,ensure_ascii=False))

@app.get("/",response_class=HTMLResponse)
def home(): return HTMLResponse((ROOT/"index.html").read_text(encoding="utf-8"))
@app.post("/api/upload")
async def upload(background_tasks:BackgroundTasks,file:UploadFile=File(...)):
    ext=Path(file.filename or "video.mp4").suffix.lower()
    if ext not in {".mp4",".mov",".m4v",".webm",".mkv",".avi"}: raise HTTPException(400,"Formato não suportado.")
    jid=uuid.uuid4().hex[:12]; dest=UP/f"{jid}{ext}"
    with dest.open("wb") as f: shutil.copyfileobj(file.file,f)
    d={"id":jid,"status":"queued","progress":0,"message":"Upload concluído","clips":[]}; (JOBS/f"{jid}.json").write_text(json.dumps(d))
    background_tasks.add_task(process,jid,dest); return JSONResponse(d)
@app.get("/api/jobs/{jid}")
def job(jid:str):
    f=JOBS/f"{jid}.json"
    if not f.exists(): raise HTTPException(404,"Trabalho não encontrado")
    return JSONResponse(json.loads(f.read_text(encoding="utf-8")))
@app.get("/api/health")
def health(): return {"ok":True,"ffmpeg":bool(shutil.which("ffmpeg"))}
